# @prodactionpro/ui-media

Общая галерея и полноэкранный просмотрщик для Content Hub, Image Production и
Playground. Код перенесён из галереи Image Production, а не реализован независимо
во втором продукте. Галерея сохраняет пропорции, просмотрщик поддерживает drag,
горизонтальный wheel/trackpad, инерцию и ленту миниатюр.

## Граница ответственности

Пакет получает готовые URL и идентификаторы. Он не содержит Next.js, маршрутов API,
S3, Workspace, авторизации, генерации, оплаты или записи в базу. Эти решения
принадлежат приложению. Не передавайте секреты в URL. Проверка доступа выполняется
сервером потребителя, а не через выбранный в браузере ID.

## Подключение

```tsx
"use client"
import { useState } from "react"
import type { MediaItem } from "@prodactionpro/ui-media"
import { MediaGallery, MediaViewer } from "@prodactionpro/ui-media/client"
import "@prodactionpro/ui-tokens/css/light.css"
import "@prodactionpro/ui-media/styles.css"

export function Library({ items }: { items: MediaItem[] }) {
  const [selectedId, setSelectedId] = useState<string | null>(null)
  return <>
    <MediaGallery items={items} onSelect={setSelectedId} />
    {selectedId && <MediaViewer items={items} selectedId={selectedId}
      onSelect={setSelectedId} onClose={() => setSelectedId(null)} />}
  </>
}
```

Тему задайте на `html`/ `body` через `data-theme`: просмотрщик использует portal
в `document.body`. В Next.js глобальные CSS импортируются в layout. Корневой
экспорт содержит только типы и чистые функции; React-компоненты и hooks доступны
через `/client` с сохранённой директивой `use client`. Peer React: 18.2 / 19.
Для `next/image` передайте `renderImage`; не теряйте `onError`, размеры, className
и style. Стандартный renderer использует обычный img.

## Контракт коллекции

`MediaItem`: стабильный уникальный `id`, разрешённый приложением `url`, опциональные
`name`, `thumbnailUrl`, `width`, `height`, `kind`, `createdAt`, `byteSize`.
Без размеров галерея использует квадратное соотношение. Видео и файлы не
притворяются изображениями; предпросмотр файла можно заменить через `renderMedia`.

Владельцем выбора остаётся приложение: `selectedId`, `onSelect`, `onClose`.
Приложение же связывает выбор с URL/history, поиском, пагинацией и Workspace.
При смене Workspace заменяйте коллекцию и закрывайте предыдущий просмотрщик.
`renderCard` заменяет карточку полностью, `renderActions` и `renderCaption` —
только нужную область. UI загрузки, ошибки и пустого результата управляется props.

## Независимые модули

`MediaViewerModule` — объект со стабильным `id`, `active`, `placement`
(`bottom` или `right`), `toolbar`, `body`, `overlay`, `media`,
`lockNavigation`, опциональными `height` и `className`.

Toolbar может оставаться доступным при выключенном body. Overlay остаётся
смонтированным, пока передан в modules: сам модуль управляет видимостью и
pointer-events. Это сохраняет нарисованную маску при переключении инструмента.
Если overlay присутствует, просмотрщик использует один stage вместо движущейся
карусели. Активный media renderer также выбирает stage. Маска может блокировать
переключение изображений, не блокируя собственные кнопки.

Модули сами владеют состоянием, обработкой и сохранением результата. В этой
итерации реальные маски/кривые/коррекция остаются независимыми адаптерами Image
Production; перенос их алгоритмов в следующие пакеты — отдельная миграция.
Playground демонстрирует inspector и тестовый overlay, не выдаёт их за редактор масок.

Внешние иконки принимаются через `icons`, подписи навигации через `labels`.
`isInteractionBlocked` предотвращает перехват клавиш/жестов при открытом меню
продукта. Нативный dialog учитывается автоматически.

## Доступность и производительность

Escape закрывает, Tab удерживается в модальном окне, фокус и прокрутка страницы
восстанавливаются после закрытия. Поля ввода не перехватывают стрелки. При
`prefers-reduced-motion` переход выполняется без анимации. На кадре не
перерисовывается React-дерево: позиции обновляются через refs, а число больших
изображений в карусели ограничено окном. Данные и страницы коллекции загружает host.

## Проверка и поставка

`pnpm --filter @prodactionpro/ui-media test`, `typecheck`, `build`;
полная матрица — `pnpm check`. Packed consumers проверяют React 18/19 и
Next.js App Router, включая server import и client directive.

До публикации canary продукты используют один собранный `.tgz` из
`pnpm --filter @prodactionpro/ui-media pack --pack-destination <consumer>/.local-packages`.
Это локальная поставка: архивы игнорируются Git, не являются опубликованным релизом
и должны быть заново подготовлены на другой машине. Перед merge/release потребителей
замените file-зависимость на проверенную exact registry-версию и обновите lockfiles.
Не используйте абсолютный путь к соседнему исходному репозиторию или npm link.
