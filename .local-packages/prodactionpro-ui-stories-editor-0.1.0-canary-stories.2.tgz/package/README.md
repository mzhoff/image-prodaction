# Shared Stories editor

Controlled Composition shell and constrained Stories authoring for Image Production and Content Hub. The host owns document persistence, media authorization, style publication and business actions.

```tsx
import { StoriesEditor, StoriesPreview, StoriesStyleEditor } from "@prodactionpro/ui-stories-editor/client"
import "@prodactionpro/ui-stories-editor/styles.css"

<StoriesEditor document={draft} onChange={setDraft} media={media} styleProfile={profile} />
```

Install the exact `@prodaction/stories-platform-contracts` peer with this canary. Import draft creation and immutable transformations from the root export. Components live behind `/client`; the root has no React runtime dependency. The host must also load its existing ui-tokens and ui-media CSS.

`EditorMedia.asset` is the portable immutable asset reference; `EditorMedia.url` is a separate preview URL and is never serialized by the editor. Supply image and video entries from the existing media gallery, or implement `onRequestMedia`. Video requires its contractual poster.

`StoriesEditor` emits drafts through `onChange(document, change)`. It preserves pasted text and offers field-level character diagnostics; publication must call the shared strict finalizer on the server. `readOnly` removes editing controls. `styleProfiles` and `onStyleProfileChange` select a pinned style revision. `StoriesStyleEditor` edits semantic tokens through `onChange` and delegates saving to `onSave`; hosts persist immutable revisions. `styleOverrides` and allowlisted `fontFamilies` model mandatory application styling.

`StoriesPreview` supports images and muted inline MP4 playback, local poll selection and explicit preview navigation. Preview choices and buttons never call production business handlers or submit survey responses. `CompositionEditorShell` exposes sidebar, canvas, inspector, toolbar and controlled history slots for existing Composition adapters.

Package checks: `pnpm --filter @prodactionpro/ui-stories-editor typecheck`, `test`, `lint`, `build`. Consumer applications must run their checks against the packed candidate before registry publication. This candidate does not imply browser/device E2E acceptance.
