# REVERIE Identity client

Exact version 0.1.0-canary.2. Shared OIDC/PKCE consumer; products keep their own sessions and databases.

`createIdentityClient` verifies state, nonce, PKCE, issuer, audience, ID token and UserInfo subject using openid-client. `identityPlugin` adapts it to Better Auth 1.6.25. Only configured HTTPS origins are used; HTTP is allowed explicitly for loopback development. Identity clients use authorization code + S256 PKCE without a distributed client secret.

Migration required before enabling: make `user.email` nullable and add nullable UNIQUE `identitySubject`. Preserve all IDs. Existing accounts are linked through a recent product session; never link by email. Do not enable cookie session caches with stale account fields. No product roles or workspace membership are imported from Identity.

POST `/identity/start`: intent login/link, method email/telegram, termsAccepted. GET `/identity/callback`: allowlisted deployment callback. Login attempts are single-use, browser-bound and expire in 5 minutes. New product users require explicit terms acceptance; existing email collision asks the user to sign into the old product account and link it.

Canary distribution: build and pack this directory once; ship the identical tarball to every consumer. It includes only the generic client and UI, never Identity server code, configuration or credentials. Registry publication is a separate release step.
