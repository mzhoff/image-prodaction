# Stories Platform

Stories Platform — модульная система создания, проверки, публикации, доставки
и измерения интерактивного контента внутри мобильных приложений.

Первый экспериментальный consumer — ТОКБЕРИ. В шторке выбранной станции
Stories заменят содержимое блока «Как это работает?», при этом текущие три
строки с иконками останутся обязательным безопасным fallback.

## Текущая стадия

`prototype / discovery`.

Сейчас репозиторий хранит продуктовые решения, визуальный и компонентный
контракт, переносимую схему данных, fixtures и инструкции интеграции. Наличие
репозитория не означает, что CMS, delivery backend, S3, targeting, рекламный
кабинет или SaaS уже разрешены к разработке.

Первый цикл проверяет только локальный UX:

- карточки Stories;
- открытие и закрытие viewer;
- горизонтальное перелистывание;
- переходы и анимацию;
- совместимость с вертикальной шторкой;
- accessibility;
- сохранение критического сценария ТОКБЕРИ и legacy fallback.

## Видение

В перспективе система соединяет несколько независимых capabilities:

- Image Production создаёт и версионирует визуальные ассеты;
- Stories domain владеет StoryDeck, ревизиями и публикациями;
- Content Hub собирает модули в единый интерфейс управления;
- Delivery API отдаёт immutable snapshots;
- платформенные renderer показывают контент в React Native, Swift и Kotlin;
- ChatModule даёт партнёру и оператору AI-copilot для создания, управления и
  анализа кампаний.

Канонический переносимый объект — versioned `StoryFeed`, а не React-компонент,
Composition graph или модель базы данных конкретного продукта.

## Навигация

- [Продуктовая инициатива](docs/00-product-initiative.md)
- [Границы продукта и систем](docs/01-product-boundaries.md)
- [План прототипа ТОКБЕРИ](docs/02-prototype-plan.md)
- [Продуктовая модель работы](docs/03-product-operating-model.md)
- [Партнёрский marketing SaaS и AI-copilot](docs/04-partner-marketing-saas.md)
- [Roadmap и gates](docs/05-roadmap.md)
- [Карта интеграций](docs/06-integration-map.md)
- [StoryFeed v1](docs/contracts/story-feed-v1.md)
- [StoryFeed v2.1](docs/contracts/story-feed-v2.md)
- [UI-контракт прототипа](docs/contracts/stories-ui-prototype-v1.md)
- [Задание агенту tokberi-mobile](docs/handoffs/tokberi-mobile-agent.md)
- [Реестр решений](docs/decisions/README.md)

## Ветки

- `main` — стабильная документированная основа;
- `dev` — интеграционная ветка;
- изменения выполняются в отдельных ветках и попадают в `dev` через PR.
