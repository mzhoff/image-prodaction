export { validatePollDefinitionV1, validatePollResponseCommandV1, validatePollResponseReceiptV1 } from '../../shared/validate-v3.mjs';
