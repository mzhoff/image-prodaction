import Ajv2020 from 'ajv/dist/2020.js';
import addFormats from 'ajv-formats';
import documentSchema from '../../contracts/story-document/1.0.0/schema.json' with { type: 'json' };
import draftSchema from '../../contracts/story-document/1.0.0/draft.schema.json' with { type: 'json' };
import feedSchema from '../../contracts/story-feed/3.0.0/schema.json' with { type: 'json' };
import hostSchema from '../../contracts/host-profile/3.0.0/schema.json' with { type: 'json' };
import styleSchema from '../../contracts/style-profile/1.0.0/schema.json' with { type: 'json' };
import pollSchema from '../../contracts/polls/1.0.0/definition.schema.json' with { type: 'json' };
import responseSchema from '../../contracts/polls/1.0.0/response.schema.json' with { type: 'json' };
import receiptSchema from '../../contracts/polls/1.0.0/receipt.schema.json' with { type: 'json' };
import { countStoryTextCharacters } from '../limits/1.0.0/index.mjs';

const ajv = new Ajv2020({ allErrors: true, strict: true });
addFormats(ajv);
const validators = Object.fromEntries(Object.entries({ document: documentSchema, draft: draftSchema, feed: feedSchema, host: hostSchema, style: styleSchema, poll: pollSchema, response: responseSchema, receipt: receiptSchema }).map(([key, value]) => [key, ajv.compile(value)]));
const validateTokens = ajv.compile({ ...styleSchema, $id: `${styleSchema.$id}:tokens`, $ref: '#/$defs/styleTokens' });
const RESERVED = new Set(['stories.next', 'stories.previous', 'stories.dismiss']);
const result = (data, issues) => issues.length ? { valid: false, issues } : { valid: true, data };
const issue = (issues, path, code, message) => issues.push({ path, code, message });
const clone = (input) => JSON.parse(JSON.stringify(input));

function shape(validator, input) {
  if (validator(input)) return { valid: true, data: input };
  return { valid: false, issues: (validator.errors ?? []).map((error) => {
    const path = `${error.instancePath}${error.keyword === 'required' ? `/${error.params.missingProperty}` : ''}` || '/';
    let message = 'Проверьте содержимое этого поля.';
    if (error.keyword === 'required') message = 'Заполните это поле перед публикацией.';
    if (error.keyword === 'maxLength') {
      const value = error.instancePath.split('/').slice(1).reduce((current, key) => current?.[key.replace(/~1/g, '/').replace(/~0/g, '~')], input);
      message = `Сократите текст на ${Math.max(1, countStoryTextCharacters(value ?? '') - error.params.limit)} символов. Максимум — ${error.params.limit}.`;
    }
    if (error.keyword === 'minLength') message = 'Добавьте текст.';
    return { path, code: `schema.${error.keyword}`, message };
  }) };
}

function unique(values, issues, path, code) {
  if (new Set(values).size !== values.length) issue(issues, path, code, 'У каждого элемента должен быть собственный идентификатор.');
}

function locale(value, issues, path) {
  try { new Intl.Locale(value); } catch { issue(issues, path, 'locale.invalid', 'Укажите поддерживаемый язык Stories.'); }
}

function canonical(value) {
  if (Array.isArray(value)) return `[${value.map(canonical).join(',')}]`;
  if (value && typeof value === 'object') return `{${Object.keys(value).sort().map((key) => `${JSON.stringify(key)}:${canonical(value[key])}`).join(',')}}`;
  return JSON.stringify(value);
}

function assets(document) {
  return [
    ['/preview/cover', document.preview.cover],
    ...document.slides.flatMap((slide, index) => {
      const path = `/slides/${index}/background/asset`;
      const asset = slide.background.asset;
      return asset.kind === 'video' ? [[path, asset], [`${path}/poster`, asset.poster]] : [[path, asset]];
    }),
  ];
}

function localOrigin(value) {
  try {
    const url = new URL(value);
    if (url.protocol !== 'http:' || url.origin !== value || url.username || url.password) return false;
    const host = url.hostname;
    return host === 'localhost' || host === '[::1]' || host.endsWith('.local') || /^127\./.test(host) || /^10\./.test(host) || /^192\.168\./.test(host) || /^172\.(1[6-9]|2[0-9]|3[01])\./.test(host);
  } catch { return false; }
}

function assetSemantics(document, issues, options = {}) {
  const identities = new Map();
  for (const [path, asset] of assets(document)) {
    const signature = canonical(asset);
    if (identities.has(asset.assetId) && identities.get(asset.assetId) !== signature) issue(issues, `${path}/assetId`, 'asset.identity_conflict', 'Один идентификатор файла указывает на разные версии.');
    identities.set(asset.assetId, signature);
    if (asset.source.kind === 'productionArtifact' && asset.provenance && (asset.source.artifactId !== asset.provenance.artifactId || asset.source.producerKey !== asset.provenance.producerKey)) issue(issues, `${path}/provenance`, 'asset.provenance_mismatch', 'Источник файла и сведения о его создании не совпадают.');
    if (asset.source.kind !== 'remote') continue;
    const url = new URL(asset.source.url);
    if (url.username || url.password) issue(issues, `${path}/source/url`, 'asset.credentials_forbidden', 'Ссылка на файл не должна содержать логин или пароль.');
    const localAllowed = (options.allowedLocalAssetOrigins ?? []).some((origin) => localOrigin(origin) && origin === url.origin);
    if (url.protocol !== 'https:' && !localAllowed) issue(issues, `${path}/source/url`, 'asset.insecure_url', 'Для публикации нужна защищённая ссылка на файл.');
  }
}

function pollSemantics(poll, issues, path = '') {
  unique(poll.options.map((option) => option.id), issues, `${path}/options`, 'poll.duplicate_option');
  if (!poll.question.trim() || poll.options.some((option) => !option.label.trim())) issue(issues, path || '/', 'poll.empty_text', 'Добавьте вопрос и подписи вариантов.');
  if (poll.selectionMode === 'single' && poll.maxSelections !== undefined) issue(issues, `${path}/maxSelections`, 'poll.single_has_max_selections', 'В этом опросе можно выбрать один ответ.');
  if (poll.selectionMode === 'multiple' && poll.maxSelections !== undefined && poll.maxSelections > poll.options.length) issue(issues, `${path}/maxSelections`, 'poll.max_selections_exceeds_options', 'Разрешённое число ответов превышает число вариантов.');
}

function documentSemantics(document, issues, options = {}) {
  locale(document.locale, issues, '/locale');
  unique(document.slides.map((slide) => slide.id), issues, '/slides', 'identity.duplicate_slide_id');
  const pollRevisions = new Map();
  for (const [index, slide] of document.slides.entries()) {
    const path = `/slides/${index}`;
    if (!slide.accessibilityLabel.trim()) issue(issues, `${path}/accessibilityLabel`, 'text.empty', 'Добавьте описание слайда.');
    if (slide.advance.mode === 'mediaEnd' && slide.background.asset.kind !== 'video') issue(issues, `${path}/advance`, 'playback.media_end_requires_video', 'Переход по окончании видео доступен только для видеослайда.');
    if (slide.background.playback && slide.background.asset.kind !== 'video') issue(issues, `${path}/background/playback`, 'playback.requires_video', 'Настройки воспроизведения относятся только к видео.');
    unique(slide.layers.map((layer) => layer.id), issues, `${path}/layers`, 'identity.duplicate_layer_id');
    for (const [layerIndex, layer] of slide.layers.entries()) {
      const layerPath = `${path}/layers/${layerIndex}`;
      if (layer.layout.order !== layerIndex) issue(issues, `${layerPath}/layout/order`, 'layout.non_canonical_order', 'Порядок слоёв должен совпадать с их порядком в редакторе.');
      if (['title', 'subtitle', 'text'].includes(layer.kind) && !layer.text.trim()) issue(issues, `${layerPath}/text`, 'text.empty', 'Добавьте текст или удалите пустой блок.');
      if (layer.kind === 'poll') {
        pollSemantics(layer.definition, issues, `${layerPath}/definition`);
        const key = `${layer.definition.pollId}/${layer.definition.revisionId}`;
        const signature = canonical(layer.definition);
        if (pollRevisions.has(key) && pollRevisions.get(key) !== signature) issue(issues, `${layerPath}/definition`, 'poll.revision_conflict', 'Разным вариантам опроса нужны разные версии.');
        pollRevisions.set(key, signature);
      }
      if (layer.kind === 'actions') {
        unique(layer.actions.map((action) => action.businessActionId), issues, `${layerPath}/actions`, 'action.duplicate');
        if (layer.actions.filter((action) => action.emphasis === 'primary').length > 1) issue(issues, `${layerPath}/actions`, 'action.multiple_primary', 'Выберите одну основную кнопку.');
        layer.actions.forEach((action, actionIndex) => {
          if (RESERVED.has(action.businessActionId)) issue(issues, `${layerPath}/actions/${actionIndex}`, 'action.viewer_command_reserved', 'Кнопки перехода принадлежат просмотрщику.');
          if (!action.label.trim()) issue(issues, `${layerPath}/actions/${actionIndex}/label`, 'text.empty', 'Добавьте подпись кнопки.');
        });
      }
    }
  }
  if (!document.preview.title.trim() || !document.preview.accessibilityLabel.trim()) issue(issues, '/preview', 'text.empty', 'Добавьте название и описание обложки.');
  assetSemantics(document, issues, options);
}

export function validateStoryDocumentV1(input, options = {}) {
  const checked = shape(validators.document, input);
  if (!checked.valid) return checked;
  const issues = [];
  documentSemantics(input, issues, options);
  return result(input, issues);
}

export function validateStoryDocumentDraftV1(input) { return shape(validators.draft, input); }

export function finalizeStoryDocumentDraftV1(input, options = {}) {
  const checked = validateStoryDocumentDraftV1(input);
  if (!checked.valid) return checked;
  const document = clone(input);
  document.schemaVersion = 'stories.document@1.0.0';
  return validateStoryDocumentV1(document, options);
}

export function validatePollDefinitionV1(input) {
  const checked = shape(validators.poll, input);
  if (!checked.valid) return checked;
  const issues = [];
  pollSemantics(input, issues);
  return result(input, issues);
}

export function validatePollResponseCommandV1(input, options = {}) {
  const checked = shape(validators.response, input);
  if (!checked.valid) return checked;
  if (!options.definition) return checked;
  const definition = validatePollDefinitionV1(options.definition);
  if (!definition.valid) return definition;
  const poll = definition.data;
  const issues = [];
  if (poll.pollId !== input.pollId || poll.revisionId !== input.pollRevisionId) issue(issues, '/pollRevisionId', 'poll.revision_mismatch', 'Ответ относится к другой версии опроса.');
  const ids = new Set(poll.options.map((option) => option.id));
  if (input.selectedOptionIds.some((id) => !ids.has(id))) issue(issues, '/selectedOptionIds', 'poll.unknown_option', 'Один из вариантов отсутствует в этом опросе.');
  const maximum = poll.selectionMode === 'single' ? 1 : (poll.maxSelections ?? poll.options.length);
  if (input.selectedOptionIds.length > maximum) issue(issues, '/selectedOptionIds', 'poll.too_many_selections', `Можно выбрать не больше ${maximum} ответов.`);
  return result(input, issues);
}

export function validatePollResponseReceiptV1(input) { return shape(validators.receipt, input); }
export function validateStoryStyleProfileV1(input) { return shape(validators.style, input); }

function mergeTokens(base, override) {
  const merged = clone(base);
  for (const [key, value] of Object.entries(override)) {
    merged[key] = value && typeof value === 'object' ? mergeTokens(merged[key] ?? {}, value) : value;
  }
  return merged;
}

export function resolveStoryStyleTokensV1({ defaults, profile, hostOverrides = {} }) {
  for (const [validator, input] of [[validateTokens, defaults], [validators.style, profile], [validateTokens, hostOverrides]]) {
    const checked = shape(validator, input);
    if (!checked.valid) return checked;
  }
  return { valid: true, data: mergeTokens(mergeTokens(defaults, profile.tokens), hostOverrides) };
}

export function validateStoryHostProfileV3(input) {
  const checked = shape(validators.host, input);
  if (!checked.valid) return checked;
  const issues = [];
  if (input.allowedAssetSourceKinds.includes('remote') && input.allowedRemoteAssetHosts.length === 0) issue(issues, '/allowedRemoteAssetHosts', 'profile.remote_hosts_required', 'Укажите разрешённые серверы файлов.');
  if (input.allowedRemoteAssetHosts.some((host) => !/^(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)(?:\.(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?))*$/.test(host) && host !== '[::1]')) issue(issues, '/allowedRemoteAssetHosts', 'profile.invalid_hostname', 'Укажите имя сервера без пути и протокола.');
  if (input.localDevelopment?.assetOrigins.some((origin) => !localOrigin(origin))) issue(issues, '/localDevelopment/assetOrigins', 'profile.invalid_local_origin', 'Незащищённые ссылки допускаются только для явно заданного локального тестового сервера.');
  const fonts = Object.values(input.styleOverrides?.typography ?? {}).map((value) => value.fontFamilyAlias).filter(Boolean);
  if (fonts.some((font) => !input.allowedFontFamilyAliases.includes(font))) issue(issues, '/styleOverrides/typography', 'profile.font_not_allowed', 'Шрифт отсутствует в целевом приложении.');
  return result(input, issues);
}

function byteLength(value) {
  return [...JSON.stringify(value)].reduce((length, character) => {
    const code = character.codePointAt(0);
    return length + (code < 128 ? 1 : code < 2048 ? 2 : code < 65536 ? 3 : 4);
  }, 0);
}

export function validateStoryFeedV3Structure(input, options = {}) {
  const checked = shape(validators.feed, input);
  if (!checked.valid) return checked;
  const issues = [];
  const now = options.now instanceof Date ? options.now.getTime() : Date.parse(options.now ?? new Date().toISOString());
  const published = Date.parse(input.publishedAt), expires = Date.parse(input.expiresAt);
  if (!Number.isFinite(now)) issue(issues, '/expiresAt', 'publication.invalid_now', 'Не удалось проверить срок публикации.');
  if (published >= expires) issue(issues, '/expiresAt', 'publication.invalid_window', 'Дата окончания должна быть позже даты публикации.');
  if (expires <= now) issue(issues, '/expiresAt', 'publication.expired', 'Срок публикации завершён.');
  if (published > now) issue(issues, '/publishedAt', 'publication.not_started', 'Публикация ещё не началась.');
  if (input.enabled && input.stories.length === 0) issue(issues, '/stories', 'publication.empty', 'Добавьте хотя бы одну Stories.');
  if (!input.enabled && input.stories.length > 0) issue(issues, '/stories', 'publication.disabled_has_content', 'Снятая публикация не должна содержать Stories.');
  if (byteLength(input) > 2000000) issue(issues, '/', 'publication.too_large', 'Уменьшите размер публикации.');
  locale(input.locale, issues, '/locale');
  unique(input.stories.map((story) => story.id), issues, '/stories', 'identity.duplicate_story_id');
  unique(input.styleProfiles.map((style) => `${style.profileId}/${style.revisionId}`), issues, '/styleProfiles', 'style.duplicate_revision');
  const styles = new Set(input.styleProfiles.map((style) => `${style.profileId}/${style.revisionId}`));
  const occurrences = [], pollRevisions = new Map(), assetIdentities = new Map();
  for (const [index, document] of input.stories.entries()) {
    const prefix = `/stories/${index}`;
    const localIssues = [];
    documentSemantics(document, localIssues, options);
    issues.push(...localIssues.map((entry) => ({ ...entry, path: `${prefix}${entry.path}` })));
    if (document.locale !== input.locale) issue(issues, `${prefix}/locale`, 'locale.mismatch', 'Язык Stories отличается от языка публикации.');
    if (!styles.has(`${document.styleProfile.profileId}/${document.styleProfile.revisionId}`)) issue(issues, `${prefix}/styleProfile`, 'style.missing_revision', 'Зафиксированная версия стиля отсутствует в публикации.');
    for (const [assetPath, asset] of assets(document)) {
      if (asset.source.kind === 'productionArtifact') issue(issues, `${prefix}${assetPath}/source`, 'asset.not_deliverable', 'Файл ещё не подготовлен для доставки в приложение.');
      const signature = canonical(asset);
      if (assetIdentities.has(asset.assetId) && assetIdentities.get(asset.assetId) !== signature) issue(issues, `${prefix}${assetPath}/assetId`, 'asset.identity_conflict', 'Идентификатор файла используется для разных версий.');
      assetIdentities.set(asset.assetId, signature);
    }
    document.slides.forEach((slide, slideIndex) => slide.layers.forEach((layer, layerIndex) => {
      if (layer.kind !== 'poll') return;
      const path = `${prefix}/slides/${slideIndex}/layers/${layerIndex}`;
      if (!layer.occurrenceId) issue(issues, `${path}/occurrenceId`, 'poll.occurrence_required', 'Опрос ещё не подготовлен для приёма ответов.');
      else occurrences.push(layer.occurrenceId);
      const key = `${layer.definition.pollId}/${layer.definition.revisionId}`, signature = canonical(layer.definition);
      if (pollRevisions.has(key) && pollRevisions.get(key) !== signature) issue(issues, `${path}/definition`, 'poll.revision_conflict', 'Разным вариантам опроса нужны разные версии.');
      pollRevisions.set(key, signature);
    }));
  }
  unique(occurrences, issues, '/stories', 'poll.duplicate_occurrence');
  return result(input, issues);
}

export function validateStoryFeedV3(input, options = {}) {
  if (!options.profile) return { valid: false, issues: [{ code: 'profile.required', path: '/profile', message: 'Выберите целевое приложение.' }] };
  const profileResult = validateStoryHostProfileV3(options.profile);
  if (!profileResult.valid) return profileResult;
  const profile = profileResult.data;
  const checked = validateStoryFeedV3Structure(input, {
    now: options.now,
    allowedLocalAssetOrigins: options.allowLocalDevelopment === true ? profile.localDevelopment?.assetOrigins : undefined,
  });
  if (!checked.valid) return checked;
  const issues = [];
  if (profile.placementKey !== input.placementKey) issue(issues, '/placementKey', 'profile.placement_mismatch', 'Stories подготовлены для другого места показа.');
  if (compareSemver(profile.rendererVersion, input.minimumRendererVersion) < 0) issue(issues, '/minimumRendererVersion', 'profile.renderer_too_old', 'Для этих Stories требуется обновление просмотрщика.');
  if (byteLength(input) > (profile.limits?.snapshotByteSize ?? 2000000)) issue(issues, '/', 'profile.snapshot_too_large', 'Публикация превышает размер, поддерживаемый приложением.');
  input.styleProfiles.forEach((style, index) => {
    if (!profile.allowedStyleProfileIds.includes(style.profileId) || !profile.allowedBaseProfileKeys.includes(style.baseProfileKey)) issue(issues, `/styleProfiles/${index}`, 'profile.style_not_allowed', 'Этот стиль не подключён к приложению.');
    if (Object.values(style.tokens.typography ?? {}).some((token) => token.fontFamilyAlias && !profile.allowedFontFamilyAliases.includes(token.fontFamilyAlias))) issue(issues, `/styleProfiles/${index}/tokens/typography`, 'profile.font_not_allowed', 'Шрифт отсутствует в приложении.');
  });
  for (const [index, document] of input.stories.entries()) {
    const prefix = `/stories/${index}`;
    for (const [path, asset] of assets(document)) {
      if (!profile.allowedMediaKinds.includes(asset.kind)) issue(issues, `${prefix}${path}/kind`, 'profile.unsupported_media', 'Этот тип медиа пока недоступен в приложении.');
      if (!profile.allowedAssetSourceKinds.includes(asset.source.kind)) issue(issues, `${prefix}${path}/source`, 'profile.unsupported_source', 'Этот источник файлов не поддерживается приложением.');
      if (asset.source.kind === 'remote' && !profile.allowedRemoteAssetHosts.map((host) => host.toLowerCase()).includes(new URL(asset.source.url).hostname.toLowerCase())) issue(issues, `${prefix}${path}/source`, 'profile.remote_host_not_allowed', 'Сервер файла не подключён к приложению.');
      const limit = profile.limits?.[asset.kind === 'video' ? 'videoByteSize' : 'imageByteSize'];
      if (limit && asset.byteSize > limit) issue(issues, `${prefix}${path}/byteSize`, 'profile.asset_too_large', 'Размер файла превышает возможности приложения.');
      if (asset.kind === 'video' && asset.durationMs > (profile.limits?.videoDurationMs ?? 120000)) issue(issues, `${prefix}${path}/durationMs`, 'profile.video_too_long', 'Сократите видео для этого приложения.');
    }
    document.slides.forEach((slide, slideIndex) => slide.layers.forEach((layer, layerIndex) => {
      const path = `${prefix}/slides/${slideIndex}/layers/${layerIndex}`;
      if (!profile.allowedLayerKinds.includes(layer.kind)) issue(issues, path, 'profile.unsupported_layer', 'Этот блок пока недоступен в приложении.');
      const textLimit = profile.limits?.[layer.kind];
      if (textLimit && typeof layer.text === 'string' && countStoryTextCharacters(layer.text) > textLimit) issue(issues, `${path}/text`, 'profile.text_too_long', `Сократите текст до ${textLimit} символов для этого приложения.`);
      if (layer.kind === 'poll' && !profile.allowedPollModes.includes(layer.definition.selectionMode)) issue(issues, path, 'profile.unsupported_poll_mode', 'Этот тип опроса не поддерживается приложением.');
      if (layer.kind === 'actions' && layer.actions.some((action) => !profile.allowedBusinessActionIds.includes(action.businessActionId))) issue(issues, path, 'profile.action_not_allowed', 'Действие кнопки не подключено к приложению.');
    }));
  }
  return result(input, issues);
}

function compareSemver(left, right) {
  const parse = (value) => { const [core, ...suffix] = value.split('-'); return { core: core.split('.'), prerelease: suffix.join('-').split('.').filter(Boolean) }; };
  const numeric = (a, b) => a.length !== b.length ? Math.sign(a.length - b.length) : a === b ? 0 : a > b ? 1 : -1;
  const a = parse(left), b = parse(right);
  for (let index = 0; index < 3; index++) { const compared = numeric(a.core[index], b.core[index]); if (compared) return compared; }
  if (!a.prerelease.length || !b.prerelease.length) return a.prerelease.length === b.prerelease.length ? 0 : a.prerelease.length ? -1 : 1;
  for (let index = 0; index < Math.max(a.prerelease.length, b.prerelease.length); index++) {
    const x = a.prerelease[index], y = b.prerelease[index];
    if (x === y) continue;
    if (x === undefined || y === undefined) return x === undefined ? -1 : 1;
    const xn = /^\d+$/.test(x), yn = /^\d+$/.test(y);
    if (xn !== yn) return xn ? -1 : 1;
    return xn ? numeric(x, y) : x > y ? 1 : -1;
  }
  return 0;
}
