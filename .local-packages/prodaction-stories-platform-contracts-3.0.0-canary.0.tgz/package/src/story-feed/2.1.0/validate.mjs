import Ajv2020 from 'ajv/dist/2020.js';
import addFormats from 'ajv-formats';

import schema from '../../../contracts/story-feed/2.1.0/schema.json' with { type: 'json' };
import profileSchema from '../../../contracts/story-feed/2.1.0/profile.schema.json' with { type: 'json' };

export const STORY_FEED_V21_SCHEMA_VERSION = 'stories.feed@2.1.0';
export const STORY_FEED_V21_PROFILE_VERSION = 'stories.profile@2.1.0';

const RESERVED_VIEWER_ACTION_IDS = new Set([
  'stories.dismiss',
  'stories.next',
  'stories.previous',
]);

const ajv = new Ajv2020({ allErrors: true, strict: true });
addFormats(ajv);
const validateSchema = ajv.compile(schema);
const validateProfileSchema = ajv.compile(profileSchema);

/**
 * Validate the portable StoryFeed v2.1 contract against a required host profile.
 * The validator never executes actions or resolves assets.
 *
 * @param {unknown} input
 * @param {{ profile?: Record<string, unknown>, now?: Date | string }} [options]
 */
export function validateStoryFeedV21(input, options = {}) {
  const structuralResult = validateStoryFeedV21Structure(input, {
    now: options.now,
  });
  if (!structuralResult.valid) {
    return structuralResult;
  }

  if (!options.profile) {
    return {
      valid: false,
      issues: [
        {
          code: 'profile.required',
          path: '/profile',
          message:
            'A validated product profile is required before rendering or handling interactions.',
        },
      ],
    };
  }

  if (!validateProfileSchema(options.profile)) {
    return {
      valid: false,
      issues: (validateProfileSchema.errors ?? []).map((error) => ({
        code: `profile.schema.${error.keyword}`,
        path: `/profile${error.instancePath || ''}`,
        message: error.message ?? 'Product profile schema validation failed.',
      })),
    };
  }

  const feed = structuralResult.feed;
  const issues = [];
  const addIssue = (path, code, message) => {
    issues.push({ path, code, message });
  };
  validateProfile(feed, options.profile, addIssue);

  return issues.length === 0 ? { valid: true, feed } : { valid: false, issues };
}

/**
 * Validate only the portable StoryFeed v2.1 structure and semantic invariants.
 * A successful result does not authorize rendering, remote asset loading,
 * business actions, or poll callbacks for a concrete product.
 *
 * @param {unknown} input
 * @param {{ now?: Date | string }} [options]
 */
export function validateStoryFeedV21Structure(input, options = {}) {
  if (!validateSchema(input)) {
    return {
      valid: false,
      issues: (validateSchema.errors ?? []).map((error) => ({
        code: `schema.${error.keyword}`,
        path: error.instancePath || '/',
        message: error.message ?? 'Schema validation failed.',
      })),
    };
  }

  const feed = /** @type {Record<string, any>} */ (input);
  const issues = [];
  const addIssue = (path, code, message) => {
    issues.push({ path, code, message });
  };

  validatePublicationWindow(feed, options.now, addIssue);
  validateLocale(feed.locale, addIssue);
  validateIdentityAndContent(feed, addIssue);
  validateRemoteAssetUrls(feed, addIssue);

  return issues.length === 0 ? { valid: true, feed } : { valid: false, issues };
}

function validateRemoteAssetUrls(feed, addIssue) {
  for (const [assetIndex, asset] of collectAssets(feed).entries()) {
    if (asset.source.kind !== 'remote') continue;

    const url = new URL(asset.source.url);
    if (url.username || url.password) {
      addIssue(
        `/assets/${assetIndex}/source/url`,
        'asset.remote_credentials_forbidden',
        'Remote asset URLs must not contain credentials.',
      );
    }
  }
}

function validatePublicationWindow(feed, now, addIssue) {
  const publishedAt = Date.parse(feed.publishedAt);
  const expiresAt = feed.expiresAt ? Date.parse(feed.expiresAt) : undefined;
  const assets = collectAssets(feed);
  const hasRemoteAsset = assets.some((asset) => asset.source.kind === 'remote');

  if (expiresAt !== undefined && publishedAt >= expiresAt) {
    addIssue(
      '/expiresAt',
      'publication.invalid_window',
      'expiresAt must be later than publishedAt.',
    );
  }

  if (hasRemoteAsset && expiresAt === undefined) {
    addIssue(
      '/expiresAt',
      'publication.remote_requires_expiry',
      'A feed with remote assets must define expiresAt.',
    );
  }

  if (hasRemoteAsset && expiresAt !== undefined) {
    const effectiveNow = now ?? new Date();
    const nowValue =
      effectiveNow instanceof Date
        ? effectiveNow.getTime()
        : Date.parse(effectiveNow);

    if (!Number.isFinite(nowValue)) {
      addIssue('/expiresAt', 'publication.invalid_now', 'now is invalid.');
    } else if (expiresAt <= nowValue) {
      addIssue(
        '/expiresAt',
        'publication.expired',
        'The remote StoryFeed snapshot has expired.',
      );
    }
  }
}

function validateLocale(locale, addIssue) {
  try {
    new Intl.Locale(locale);
  } catch {
    addIssue('/locale', 'locale.invalid', 'locale must be a valid BCP 47 tag.');
  }
}

function validateIdentityAndContent(feed, addIssue) {
  assertUnique(
    feed.stories.map((story) => story.id),
    '/stories',
    'identity.duplicate_story_id',
    addIssue,
  );
  assertUnique(
    feed.stories.map((story) => story.revisionId),
    '/stories',
    'identity.duplicate_revision_id',
    addIssue,
  );

  const slideIds = [];

  for (const [storyIndex, story] of feed.stories.entries()) {
    for (const [slideIndex, slide] of story.slides.entries()) {
      const slidePath = `/stories/${storyIndex}/slides/${slideIndex}`;
      slideIds.push(slide.id);

      assertUnique(
        slide.layers.map((layer) => layer.id),
        `${slidePath}/layers`,
        'identity.duplicate_layer_id',
        addIssue,
      );

      for (const [layerIndex, layer] of slide.layers.entries()) {
        const layerPath = `${slidePath}/layers/${layerIndex}`;

        if (layer.layout.order !== layerIndex) {
          addIssue(
            `${layerPath}/layout/order`,
            'layout.non_canonical_order',
            'Layer order must match its zero-based position in the layers array.',
          );
        }

        if (layer.kind === 'poll') {
          validatePoll(layer, layerPath, addIssue);
        }

        if (layer.kind === 'actions') {
          validateActions(layer, layerPath, addIssue);
        }
      }
    }
  }

  assertUnique(
    slideIds,
    '/stories/*/slides',
    'identity.duplicate_slide_id',
    addIssue,
  );
}

function validatePoll(layer, path, addIssue) {
  assertUnique(
    layer.options.map((option) => option.id),
    `${path}/options`,
    'identity.duplicate_poll_option_id',
    addIssue,
  );

  if (layer.selectionMode === 'single' && layer.maxSelections !== undefined) {
    addIssue(
      `${path}/maxSelections`,
      'poll.single_has_max_selections',
      'A single-choice poll must not define maxSelections.',
    );
  }

  if (
    layer.selectionMode === 'multiple' &&
    layer.maxSelections !== undefined &&
    layer.maxSelections > layer.options.length
  ) {
    addIssue(
      `${path}/maxSelections`,
      'poll.max_selections_exceeds_options',
      'maxSelections cannot exceed the number of poll options.',
    );
  }

  if (
    layer.answerHandling.mode === 'hostCallback' &&
    RESERVED_VIEWER_ACTION_IDS.has(layer.answerHandling.businessActionId)
  ) {
    addIssue(
      `${path}/answerHandling/businessActionId`,
      'action.viewer_command_reserved',
      'Viewer navigation commands cannot be used as business actions.',
    );
  }
}

function validateActions(layer, path, addIssue) {
  assertUnique(
    layer.actions.map((action) => action.businessActionId),
    `${path}/actions`,
    'identity.duplicate_business_action_id',
    addIssue,
  );

  const primaryCount = layer.actions.filter(
    (action) => action.emphasis === 'primary',
  ).length;

  if (primaryCount > 1) {
    addIssue(
      `${path}/actions`,
      'action.multiple_primary',
      'An actions layer can contain at most one primary action.',
    );
  }

  for (const [actionIndex, action] of layer.actions.entries()) {
    if (RESERVED_VIEWER_ACTION_IDS.has(action.businessActionId)) {
      addIssue(
        `${path}/actions/${actionIndex}/businessActionId`,
        'action.viewer_command_reserved',
        'Viewer navigation commands cannot be used as business actions.',
      );
    }
  }
}

function validateProfile(feed, profile, addIssue) {
  if (profile.schemaVersion !== feed.schemaVersion) {
    addIssue(
      '/schemaVersion',
      'profile.schema_mismatch',
      'StoryFeed schemaVersion does not match the product profile.',
    );
  }

  if (profile.placementKey !== feed.placementKey) {
    addIssue(
      '/placementKey',
      'profile.placement_mismatch',
      'StoryFeed placementKey does not match the product profile.',
    );
  }

  if (
    typeof profile.rendererVersion === 'string' &&
    compareSemver(profile.rendererVersion, feed.minimumRendererVersion) < 0
  ) {
    addIssue(
      '/minimumRendererVersion',
      'profile.renderer_too_old',
      'The product profile renderer is older than minimumRendererVersion.',
    );
  }

  const allowedSourceKinds = new Set(profile.allowedAssetSourceKinds ?? []);
  const allowedRemoteHosts = new Set(
    (profile.allowedRemoteAssetHosts ?? []).map((host) => host.toLowerCase()),
  );
  const allowedLayoutIntents = new Set(profile.allowedLayoutIntents ?? []);
  const allowedRegions = new Set(profile.allowedRegions ?? []);
  const allowedLayerKinds = new Set(profile.allowedLayerKinds ?? []);
  const allowedActionIds = new Set(profile.allowedBusinessActionIds ?? []);
  const allowedPollModes = new Set(profile.allowedPollAnswerHandling ?? []);

  for (const [assetIndex, asset] of collectAssets(feed).entries()) {
    if (!allowedSourceKinds.has(asset.source.kind)) {
      addIssue(
        `/assets/${assetIndex}/source/kind`,
        'profile.unsupported_asset_source',
        `Asset source is not supported by the profile: ${asset.source.kind}.`,
      );
    }

    if (
      asset.source.kind === 'remote' &&
      !allowedRemoteHosts.has(new URL(asset.source.url).hostname.toLowerCase())
    ) {
      addIssue(
        `/assets/${assetIndex}/source/url`,
        'profile.remote_host_not_allowed',
        'Remote asset host is not allowed by the product profile.',
      );
    }
  }

  for (const [storyIndex, story] of feed.stories.entries()) {
    for (const [slideIndex, slide] of story.slides.entries()) {
      const slidePath = `/stories/${storyIndex}/slides/${slideIndex}`;

      if (!allowedLayoutIntents.has(slide.layoutIntent)) {
        addIssue(
          `${slidePath}/layoutIntent`,
          'profile.unsupported_layout_intent',
          `Layout intent is not supported by the profile: ${slide.layoutIntent}.`,
        );
      }

      for (const [layerIndex, layer] of slide.layers.entries()) {
        const layerPath = `${slidePath}/layers/${layerIndex}`;

        if (!allowedLayerKinds.has(layer.kind)) {
          addIssue(
            `${layerPath}/kind`,
            'profile.unsupported_layer_kind',
            `Layer kind is not supported by the profile: ${layer.kind}.`,
          );
        }

        if (!allowedRegions.has(layer.layout.region)) {
          addIssue(
            `${layerPath}/layout/region`,
            'profile.unsupported_region',
            `Layout region is not supported by the profile: ${layer.layout.region}.`,
          );
        }

        if (layer.kind === 'poll') {
          if (!allowedPollModes.has(layer.answerHandling.mode)) {
            addIssue(
              `${layerPath}/answerHandling/mode`,
              'profile.unsupported_poll_handling',
              `Poll answer handling is not supported by the profile: ${layer.answerHandling.mode}.`,
            );
          }

          if (
            layer.answerHandling.mode === 'hostCallback' &&
            !allowedActionIds.has(layer.answerHandling.businessActionId)
          ) {
            addIssue(
              `${layerPath}/answerHandling/businessActionId`,
              'profile.action_not_allowed',
              `Business action is not allowed by the profile: ${layer.answerHandling.businessActionId}.`,
            );
          }
        }

        if (layer.kind === 'actions') {
          for (const [actionIndex, action] of layer.actions.entries()) {
            if (!allowedActionIds.has(action.businessActionId)) {
              addIssue(
                `${layerPath}/actions/${actionIndex}/businessActionId`,
                'profile.action_not_allowed',
                `Business action is not allowed by the profile: ${action.businessActionId}.`,
              );
            }
          }
        }
      }
    }
  }
}

function collectAssets(feed) {
  return feed.stories.flatMap((story) => [
    story.preview.cover,
    ...story.slides.map((slide) => slide.background.asset),
  ]);
}

function assertUnique(values, path, code, addIssue) {
  const seen = new Set();

  for (const value of values) {
    if (seen.has(value)) {
      addIssue(path, code, `Duplicate identifier: ${value}.`);
      return;
    }

    seen.add(value);
  }
}

function compareSemver(left, right) {
  const leftParts = parseSemver(left);
  const rightParts = parseSemver(right);

  if (!leftParts || !rightParts) {
    return -1;
  }

  for (let index = 0; index < 3; index += 1) {
    const comparison = compareNumericStrings(
      leftParts.core[index],
      rightParts.core[index],
    );
    if (comparison !== 0) return comparison;
  }

  if (leftParts.prerelease.length === 0 || rightParts.prerelease.length === 0) {
    if (leftParts.prerelease.length === rightParts.prerelease.length) return 0;
    return leftParts.prerelease.length === 0 ? 1 : -1;
  }

  const length = Math.max(
    leftParts.prerelease.length,
    rightParts.prerelease.length,
  );
  for (let index = 0; index < length; index += 1) {
    const leftIdentifier = leftParts.prerelease[index];
    const rightIdentifier = rightParts.prerelease[index];
    if (leftIdentifier === undefined || rightIdentifier === undefined) {
      if (leftIdentifier === rightIdentifier) return 0;
      return leftIdentifier === undefined ? -1 : 1;
    }
    if (leftIdentifier === rightIdentifier) continue;

    const leftNumeric = /^[0-9]+$/.test(leftIdentifier);
    const rightNumeric = /^[0-9]+$/.test(rightIdentifier);
    if (leftNumeric && rightNumeric) {
      return compareNumericStrings(leftIdentifier, rightIdentifier);
    }
    if (leftNumeric !== rightNumeric) return leftNumeric ? -1 : 1;
    return leftIdentifier > rightIdentifier ? 1 : -1;
  }

  return 0;
}

function compareNumericStrings(left, right) {
  const normalizedLeft = left.replace(/^0+(?=[0-9])/, '');
  const normalizedRight = right.replace(/^0+(?=[0-9])/, '');

  if (normalizedLeft.length !== normalizedRight.length) {
    return normalizedLeft.length > normalizedRight.length ? 1 : -1;
  }
  if (normalizedLeft === normalizedRight) return 0;
  return normalizedLeft > normalizedRight ? 1 : -1;
}

function parseSemver(value) {
  const match =
    /^(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)(?:-([0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*))?$/.exec(
      value,
    );

  return match
    ? {
        core: match.slice(1, 4),
        prerelease: match[4]?.split('.') ?? [],
      }
    : undefined;
}
