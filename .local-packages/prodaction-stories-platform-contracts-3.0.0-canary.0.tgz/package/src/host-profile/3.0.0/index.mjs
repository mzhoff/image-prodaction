export { validateStoryHostProfileV3 } from '../../shared/validate-v3.mjs';
