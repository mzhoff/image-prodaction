export { validateStoryStyleProfileV1, resolveStoryStyleTokensV1 } from '../../shared/validate-v3.mjs';
