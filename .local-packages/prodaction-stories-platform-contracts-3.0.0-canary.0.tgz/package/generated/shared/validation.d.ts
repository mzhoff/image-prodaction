export type ContractValidationIssue = { code: string; path: string; message: string };
export type ContractValidationResult<T> = { valid: true; data: T } | { valid: false; issues: ContractValidationIssue[] };
export type DocumentValidationOptions = { allowedLocalAssetOrigins?: readonly string[] };
