export declare const STORY_CONTENT_LIMITS_V1: Readonly<{"title":100,"subtitle":160,"text":600,"previewTitle":100,"previewSubtitle":160,"pollQuestion":180,"pollOption":120,"pollOptions":6,"actionLabel":60,"stories":20,"slides":12,"layers":8,"videoDurationMs":120000,"imageByteSize":20000000,"videoByteSize":100000000}>;
export declare function countStoryTextCharacters(value: string): number;
