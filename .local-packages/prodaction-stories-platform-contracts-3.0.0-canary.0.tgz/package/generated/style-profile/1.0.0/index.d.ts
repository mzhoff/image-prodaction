export * from './types.js';
import type { StoryStyleProfileV1, StoryStyleTokensV1 } from './types.js';
import type { ContractValidationResult } from '../../shared/validation.js';
export declare function validateStoryStyleProfileV1(input: unknown): ContractValidationResult<StoryStyleProfileV1>;
export declare function resolveStoryStyleTokensV1(input: { defaults: StoryStyleTokensV1; profile: StoryStyleProfileV1; hostOverrides?: StoryStyleTokensV1 }): ContractValidationResult<StoryStyleTokensV1>;
