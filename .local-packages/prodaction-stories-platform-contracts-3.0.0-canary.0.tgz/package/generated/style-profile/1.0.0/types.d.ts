/** Generated from style-profile/1.0.0/schema.json. Checksum: sha256:caa988ed4807d1924144de6a9ff61b50e25a64f7e8e6bf96a7ada38bd955b885. Do not edit. */

export type Id = string;
export type Key = string;

export interface StoryStyleProfileV1 {
  schemaVersion: 'stories.style-profile@1.0.0';
  profileId: Id;
  revisionId: Id;
  name: string;
  baseProfileKey: Key;
  tokens: StoryStyleTokensV1;
}
export interface StoryStyleTokensV1 {
  typography?: {
    title?: TypographyToken;
    subtitle?: TypographyToken;
    body?: TypographyToken;
    pollQuestion?: TypographyToken;
    pollOption?: TypographyToken;
    action?: TypographyToken;
  };
  colors?: {
    content?: string;
    surface?: string;
    accent?: string;
    selected?: string;
    disabled?: string;
  };
  spacing?: {
    contentPadding?: number;
    layerGap?: number;
    optionGap?: number;
  };
  radii?: {
    action?: number;
    option?: number;
  };
  overlay?: {
    color?: string;
    opacity?: number;
  };
}
export interface TypographyToken {
  fontFamilyAlias?: Key;
  fontSize?: number;
  lineHeight?: number;
  fontWeight?: 400 | 500 | 600 | 700 | 800 | 900;
}
