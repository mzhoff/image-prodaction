/** Generated from story-document/1.0.0/schema.json. Checksum: sha256:77a362ede2a258277f47f652c48f579173c4fd3b25ad650cbdc1e899cba5e49f. Do not edit. */

export type Id = string;
export type AssetSource = BundledAssetSource | RemoteAssetSource | ProductionArtifactSource;
export type Key = string;
export type StoryBackgroundAssetV3 = StoryImageAssetV3 | StoryVideoAssetV3;
export type Advance =
  | {
      mode: 'manual';
    }
  | {
      mode: 'timer';
      durationMs: number;
    }
  | {
      mode: 'mediaEnd';
    };
export type StoryLayerV3 = TitleLayer | SubtitleLayer | TextLayer | PollLayer | ActionsLayer;

export interface StoryDocumentV1 {
  schemaVersion: 'stories.document@1.0.0';
  id: Id;
  revisionId: Id;
  locale: string;
  styleProfile: StoryStyleReferenceV1;
  preview: Preview;
  /**
   * @minItems 1
   * @maxItems 12
   */
  slides: [StorySlideV3, ...StorySlideV3[]];
}
export interface StoryStyleReferenceV1 {
  profileId: Id;
  revisionId: Id;
}
export interface Preview {
  title: string;
  subtitle?: string;
  accessibilityLabel: string;
  cover: StoryImageAssetV3;
}
export interface StoryImageAssetV3 {
  assetId: Id;
  kind: 'image';
  source: AssetSource;
  mimeType: 'image/webp' | 'image/png' | 'image/jpeg';
  width: number;
  height: number;
  byteSize: number;
  altText: string;
  provenance?: AssetProvenance;
}
export interface BundledAssetSource {
  kind: 'bundled';
  key: Key;
}
export interface RemoteAssetSource {
  kind: 'remote';
  url: string;
  checksum: string;
}
export interface ProductionArtifactSource {
  kind: 'productionArtifact';
  artifactId: Id;
  producerKey: Key;
  checksum: string;
}
export interface AssetProvenance {
  producerKey: Key;
  capabilityKey: Key;
  pipelineVersion: Id;
  artifactId: Id;
}
export interface StorySlideV3 {
  id: Id;
  accessibilityLabel: string;
  background: Background;
  advance: Advance;
  layoutIntent: 'fullBleedOverlay';
  /**
   * @maxItems 8
   */
  layers: StoryLayerV3[];
}
export interface Background {
  asset: StoryBackgroundAssetV3;
  fit: 'cover';
  focalPoint?: FocalPoint;
  playback?: {
    startMuted: true;
    loop: false;
    failure: 'posterManual';
  };
}
export interface StoryVideoAssetV3 {
  assetId: Id;
  kind: 'video';
  source: AssetSource;
  mimeType: 'video/mp4';
  width: number;
  height: number;
  byteSize: number;
  durationMs: number;
  altText: string;
  poster: StoryImageAssetV3;
  provenance?: AssetProvenance;
}
export interface FocalPoint {
  x: number;
  y: number;
}
export interface TitleLayer {
  id: Id;
  kind: 'title';
  layout: LayerLayout;
  text: string;
  contrastIntent: 'lightContent' | 'darkContent';
}
export interface LayerLayout {
  region: 'top' | 'center' | 'bottom';
  order: number;
  alignment: 'start' | 'center';
}
export interface SubtitleLayer {
  id: Id;
  kind: 'subtitle';
  layout: LayerLayout;
  text: string;
  contrastIntent: 'lightContent' | 'darkContent';
}
export interface TextLayer {
  id: Id;
  kind: 'text';
  layout: LayerLayout;
  text: string;
  contrastIntent: 'lightContent' | 'darkContent';
}
export interface PollLayer {
  id: Id;
  kind: 'poll';
  layout: BottomLayerLayout;
  definition: PollDefinitionV1;
  occurrenceId?: Id;
  contrastIntent?: 'lightContent' | 'darkContent';
}
export interface BottomLayerLayout {
  region: 'bottom';
  order: number;
  alignment: 'start' | 'center';
}
export interface PollDefinitionV1 {
  schemaVersion: 'polls.definition@1.0.0';
  pollId: Id;
  revisionId: Id;
  question: string;
  selectionMode: 'single' | 'multiple';
  maxSelections?: number;
  /**
   * @minItems 2
   * @maxItems 6
   */
  options: [PollOption, PollOption, ...PollOption[]];
}
export interface PollOption {
  id: Id;
  label: string;
}
export interface ActionsLayer {
  id: Id;
  kind: 'actions';
  layout: BottomLayerLayout;
  arrangement: 'horizontal' | 'vertical';
  /**
   * @minItems 1
   * @maxItems 2
   */
  actions: [BusinessAction, ...BusinessAction[]];
}
export interface BusinessAction {
  businessActionId: Key;
  label: string;
  accessibilityLabel?: string;
  emphasis: 'primary' | 'secondary' | 'tertiary';
}
