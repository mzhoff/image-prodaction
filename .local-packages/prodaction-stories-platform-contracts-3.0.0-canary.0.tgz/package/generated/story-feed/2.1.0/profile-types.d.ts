/**
 * Generated from stories.profile@2.1.0.
 * Schema checksum: sha256:c9c84252df4e1bdb2fae5a07e4f0f0bbbfe4bdc4f0d31dae7d7b8786e8e45e8b
 * Do not edit by hand.
 */

export type StoryFeedRendererProfileV21 = {
  profileVersion: 'stories.profile@2.1.0';
  profileKey: Key;
  schemaVersion: 'stories.feed@2.1.0';
  placementKey: Key;
  rendererVersion: Semver;
  rendererStyleProfileKey: Key;
  contentStatus: Key;
  entryPresentation: {
    size: 'small' | 'medium' | 'large';
    shape: 'square' | 'roundedSquare' | 'circle';
  };
  /**
   * @minItems 1
   */
  allowedAssetSourceKinds: ['bundled' | 'remote', ...('bundled' | 'remote')[]];
  /**
   * @minItems 1
   */
  allowedRemoteAssetHosts?: [string, ...string[]];
  /**
   * @minItems 1
   */
  allowedLayoutIntents: ['fullBleedOverlay', ...'fullBleedOverlay'[]];
  /**
   * @minItems 1
   */
  allowedRegions: ['top' | 'center' | 'bottom', ...('top' | 'center' | 'bottom')[]];
  /**
   * @minItems 1
   */
  allowedLayerKinds: ['title' | 'text' | 'poll' | 'actions', ...('title' | 'text' | 'poll' | 'actions')[]];
  allowedBusinessActionIds: Key[];
  /**
   * @minItems 1
   */
  allowedPollAnswerHandling: ['sessionOnly' | 'hostCallback', ...('sessionOnly' | 'hostCallback')[]];
  fallbackKey: Key;
};
/**
 * This interface was referenced by `undefined`'s JSON-Schema
 * via the `definition` "key".
 */
export type Key = string;
/**
 * This interface was referenced by `undefined`'s JSON-Schema
 * via the `definition` "semver".
 */
export type Semver = string;
