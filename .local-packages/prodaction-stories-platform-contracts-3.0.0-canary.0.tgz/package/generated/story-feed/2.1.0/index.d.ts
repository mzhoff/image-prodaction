/** Generated package declarations. Do not edit by hand. */
import type { StoryFeedSnapshotV21 } from './types.js';
import type { StoryFeedRendererProfileV21 } from './profile-types.js';

export * from './types.js';
export type { StoryFeedRendererProfileV21 } from './profile-types.js';

export type StoryFeedValidationIssue = {
  code: string;
  path: string;
  message: string;
};

export type StoryFeedValidationResult =
  | { valid: true; feed: StoryFeedSnapshotV21 }
  | { valid: false; issues: StoryFeedValidationIssue[] };

export declare const STORY_FEED_V21_SCHEMA_VERSION: 'stories.feed@2.1.0';
export declare const STORY_FEED_V21_PROFILE_VERSION: 'stories.profile@2.1.0';

export declare function validateStoryFeedV21(
  input: unknown,
  options?: {
    profile?: StoryFeedRendererProfileV21;
    now?: Date | string;
  },
): StoryFeedValidationResult;

export declare function validateStoryFeedV21Structure(
  input: unknown,
  options?: {
    now?: Date | string;
  },
): StoryFeedValidationResult;
