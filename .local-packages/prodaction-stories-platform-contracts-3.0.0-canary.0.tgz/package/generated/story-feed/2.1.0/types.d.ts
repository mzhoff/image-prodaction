/**
 * Generated from stories.feed@2.1.0.
 * Schema checksum: sha256:74bd1b4e7b1c2de60038ae6dc56b525edd10cdb1bcf2a6caa06dfbece5da9a03
 * Do not edit by hand.
 */

export type StoryFeedSnapshotV21 = {
  schemaVersion: 'stories.feed@2.1.0';
  snapshotId: Id;
  snapshotRevision: number;
  placementKey: Key;
  locale: string;
  publishedAt: string;
  expiresAt?: string;
  enabled: boolean;
  minimumRendererVersion: Semver;
  tracking?: Tracking;
  /**
   * @maxItems 20
   */
  stories: Story[];
};
/**
 * This interface was referenced by `undefined`'s JSON-Schema
 * via the `definition` "id".
 */
export type Id = string;
/**
 * This interface was referenced by `undefined`'s JSON-Schema
 * via the `definition` "key".
 */
export type Key = string;
/**
 * This interface was referenced by `undefined`'s JSON-Schema
 * via the `definition` "semver".
 */
export type Semver = string;
/**
 * This interface was referenced by `undefined`'s JSON-Schema
 * via the `definition` "imageAsset".
 */
export type ImageAsset = BundledImageAsset | RemoteImageAsset;
/**
 * This interface was referenced by `undefined`'s JSON-Schema
 * via the `definition` "advance".
 */
export type Advance =
  | {
      mode: 'manual';
    }
  | {
      mode: 'timer';
      durationMs: number;
    };
/**
 * This interface was referenced by `undefined`'s JSON-Schema
 * via the `definition` "layer".
 */
export type Layer = TitleLayer | TextLayer | PollLayer | ActionsLayer;
/**
 * This interface was referenced by `undefined`'s JSON-Schema
 * via the `definition` "pollAnswerHandling".
 */
export type PollAnswerHandling =
  | {
      mode: 'sessionOnly';
    }
  | {
      mode: 'hostCallback';
      businessActionId: Key;
    };
/**
 * This interface was referenced by `undefined`'s JSON-Schema
 * via the `definition` "assetSource".
 */
export type AssetSource = BundledAssetSource | RemoteAssetSource;

/**
 * This interface was referenced by `undefined`'s JSON-Schema
 * via the `definition` "tracking".
 */
export interface Tracking {
  campaignKey?: Key;
  creativeKey?: Key;
  experiment?: {
    experimentKey: Key;
    variantKey: Key;
  };
}
/**
 * This interface was referenced by `undefined`'s JSON-Schema
 * via the `definition` "story".
 */
export interface Story {
  id: Id;
  revisionId: Id;
  preview: Preview;
  tracking?: Tracking;
  /**
   * @minItems 1
   * @maxItems 12
   */
  slides: [Slide, ...Slide[]];
}
/**
 * This interface was referenced by `undefined`'s JSON-Schema
 * via the `definition` "preview".
 */
export interface Preview {
  title: string;
  subtitle?: string;
  accessibilityLabel: string;
  cover: ImageAsset;
}
/**
 * This interface was referenced by `undefined`'s JSON-Schema
 * via the `definition` "bundledImageAsset".
 */
export interface BundledImageAsset {
  assetId: Id;
  kind: 'image';
  source: BundledAssetSource;
  mimeType: 'image/webp' | 'image/png' | 'image/jpeg';
  width: number;
  height: number;
  byteSize?: number;
  altText: string;
  provenance?: AssetProvenance;
}
/**
 * This interface was referenced by `undefined`'s JSON-Schema
 * via the `definition` "bundledAssetSource".
 */
export interface BundledAssetSource {
  kind: 'bundled';
  key: Key;
}
/**
 * This interface was referenced by `undefined`'s JSON-Schema
 * via the `definition` "assetProvenance".
 */
export interface AssetProvenance {
  producerKey: Key;
  capabilityKey: Key;
  pipelineVersion: Id;
  artifactId: Id;
}
/**
 * This interface was referenced by `undefined`'s JSON-Schema
 * via the `definition` "remoteImageAsset".
 */
export interface RemoteImageAsset {
  assetId: Id;
  kind: 'image';
  source: RemoteAssetSource;
  mimeType: 'image/webp' | 'image/png' | 'image/jpeg';
  width: number;
  height: number;
  byteSize: number;
  altText: string;
  provenance?: AssetProvenance;
}
/**
 * This interface was referenced by `undefined`'s JSON-Schema
 * via the `definition` "remoteAssetSource".
 */
export interface RemoteAssetSource {
  kind: 'remote';
  url: string;
  checksum: string;
}
/**
 * This interface was referenced by `undefined`'s JSON-Schema
 * via the `definition` "slide".
 */
export interface Slide {
  id: Id;
  accessibilityLabel: string;
  background: Background;
  advance: Advance;
  layoutIntent: 'fullBleedOverlay';
  /**
   * @maxItems 8
   */
  layers: Layer[];
}
/**
 * This interface was referenced by `undefined`'s JSON-Schema
 * via the `definition` "background".
 */
export interface Background {
  asset: ImageAsset;
  fit: 'cover';
  focalPoint?: FocalPoint;
}
/**
 * This interface was referenced by `undefined`'s JSON-Schema
 * via the `definition` "focalPoint".
 */
export interface FocalPoint {
  x: number;
  y: number;
}
/**
 * This interface was referenced by `undefined`'s JSON-Schema
 * via the `definition` "titleLayer".
 */
export interface TitleLayer {
  id: Id;
  kind: 'title';
  layout: LayerLayout;
  text: string;
  contrastIntent: 'lightContent' | 'darkContent';
}
/**
 * This interface was referenced by `undefined`'s JSON-Schema
 * via the `definition` "layerLayout".
 */
export interface LayerLayout {
  region: 'top' | 'center' | 'bottom';
  order: number;
  alignment: 'start' | 'center';
}
/**
 * This interface was referenced by `undefined`'s JSON-Schema
 * via the `definition` "textLayer".
 */
export interface TextLayer {
  id: Id;
  kind: 'text';
  layout: LayerLayout;
  text: string;
  contrastIntent: 'lightContent' | 'darkContent';
}
/**
 * This interface was referenced by `undefined`'s JSON-Schema
 * via the `definition` "pollLayer".
 */
export interface PollLayer {
  id: Id;
  kind: 'poll';
  layout: BottomLayerLayout;
  question: string;
  selectionMode: 'single' | 'multiple';
  maxSelections?: number;
  /**
   * @minItems 2
   * @maxItems 6
   */
  options: [PollOption, PollOption, ...PollOption[]];
  answerHandling: PollAnswerHandling;
  contrastIntent?: 'lightContent' | 'darkContent';
}
/**
 * This interface was referenced by `undefined`'s JSON-Schema
 * via the `definition` "bottomLayerLayout".
 */
export interface BottomLayerLayout {
  region: 'bottom';
  order: number;
  alignment: 'start' | 'center';
}
/**
 * This interface was referenced by `undefined`'s JSON-Schema
 * via the `definition` "pollOption".
 */
export interface PollOption {
  id: Id;
  label: string;
}
/**
 * This interface was referenced by `undefined`'s JSON-Schema
 * via the `definition` "actionsLayer".
 */
export interface ActionsLayer {
  id: Id;
  kind: 'actions';
  layout: BottomLayerLayout;
  arrangement: 'horizontal' | 'vertical';
  /**
   * @minItems 1
   * @maxItems 2
   */
  actions: [BusinessAction, ...BusinessAction[]];
}
/**
 * This interface was referenced by `undefined`'s JSON-Schema
 * via the `definition` "businessAction".
 */
export interface BusinessAction {
  businessActionId: Key;
  label: string;
  accessibilityLabel?: string;
  emphasis: 'primary' | 'secondary' | 'tertiary';
}
