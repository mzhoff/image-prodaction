export * from './types.js';
import type { StoryFeedSnapshotV3 } from './types.js';
import type { StoryHostProfileV3 } from '../../host-profile/3.0.0/types.js';
import type { ContractValidationResult, DocumentValidationOptions } from '../../shared/validation.js';
export declare function validateStoryFeedV3Structure(input: unknown, options?: DocumentValidationOptions & { now?: Date | string }): ContractValidationResult<StoryFeedSnapshotV3>;
export declare function validateStoryFeedV3(input: unknown, options?: { profile?: StoryHostProfileV3; now?: Date | string; allowLocalDevelopment?: boolean }): ContractValidationResult<StoryFeedSnapshotV3>;
