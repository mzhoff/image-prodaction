/** Generated from host-profile/3.0.0/schema.json. Checksum: sha256:6d088b2e61a7e06db8c8327718e311e030f54ccd3017c8c71c37d1742f32661a. Do not edit. */

export type Key = string;
export type Semver = string;
export type Id = string;

export interface StoryHostProfileV3 {
  schemaVersion: 'stories.profile@3.0.0';
  profileKey: Key;
  placementKey: Key;
  rendererVersion: Semver;
  /**
   * @minItems 1
   * @maxItems 2
   */
  allowedAssetSourceKinds: ['bundled' | 'remote', ...('bundled' | 'remote')[]];
  /**
   * @minItems 0
   * @maxItems 30
   */
  allowedRemoteAssetHosts: string[];
  /**
   * @minItems 1
   * @maxItems 2
   */
  allowedMediaKinds: ['image' | 'video', ...('image' | 'video')[]];
  /**
   * @minItems 1
   * @maxItems 5
   */
  allowedLayerKinds: [
    'title' | 'subtitle' | 'text' | 'poll' | 'actions',
    ...('title' | 'subtitle' | 'text' | 'poll' | 'actions')[]
  ];
  /**
   * @minItems 0
   * @maxItems 100
   */
  allowedBusinessActionIds: Key[];
  /**
   * @minItems 0
   * @maxItems 2
   */
  allowedPollModes: ('single' | 'multiple')[];
  /**
   * @minItems 1
   * @maxItems 100
   */
  allowedStyleProfileIds: [Id, ...Id[]];
  /**
   * @minItems 1
   * @maxItems 100
   */
  allowedBaseProfileKeys: [Key, ...Key[]];
  /**
   * @minItems 1
   * @maxItems 30
   */
  allowedFontFamilyAliases: [Key, ...Key[]];
  styleOverrides?: StoryStyleTokensV1;
  fallbackKey: Key;
  localDevelopment?: {
    /**
     * @minItems 1
     * @maxItems 10
     */
    assetOrigins: [string, ...string[]];
  };
  limits?: {
    title?: number;
    subtitle?: number;
    text?: number;
    imageByteSize?: number;
    videoByteSize?: number;
    videoDurationMs?: number;
    snapshotByteSize?: number;
  };
}
export interface StoryStyleTokensV1 {
  typography?: {
    title?: TypographyToken;
    subtitle?: TypographyToken;
    body?: TypographyToken;
    pollQuestion?: TypographyToken;
    pollOption?: TypographyToken;
    action?: TypographyToken;
  };
  colors?: {
    content?: string;
    surface?: string;
    accent?: string;
    selected?: string;
    disabled?: string;
  };
  spacing?: {
    contentPadding?: number;
    layerGap?: number;
    optionGap?: number;
  };
  radii?: {
    action?: number;
    option?: number;
  };
  overlay?: {
    color?: string;
    opacity?: number;
  };
}
export interface TypographyToken {
  fontFamilyAlias?: Key;
  fontSize?: number;
  lineHeight?: number;
  fontWeight?: 400 | 500 | 600 | 700 | 800 | 900;
}
