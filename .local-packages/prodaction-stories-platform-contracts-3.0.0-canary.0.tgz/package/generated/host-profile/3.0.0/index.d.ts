export * from './types.js';
import type { StoryHostProfileV3 } from './types.js';
import type { ContractValidationResult } from '../../shared/validation.js';
export declare function validateStoryHostProfileV3(input: unknown): ContractValidationResult<StoryHostProfileV3>;
