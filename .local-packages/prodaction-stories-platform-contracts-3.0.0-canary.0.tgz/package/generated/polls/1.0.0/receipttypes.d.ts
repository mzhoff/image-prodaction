/** Generated from polls/1.0.0/receipt.schema.json. Checksum: sha256:fb166a3940305f51d3e5f34bff4266149b3b9b7ba3961ec6771fa7dafcaae13b. Do not edit. */

export type Id = string;

export interface PollResponseReceiptV1 {
  schemaVersion: 'polls.receipt@1.0.0';
  status: 'accepted';
  submissionId: Id;
  answerId: Id;
  pollId: Id;
  pollRevisionId: Id;
  occurrenceId: Id;
  acceptedAt: string;
}
