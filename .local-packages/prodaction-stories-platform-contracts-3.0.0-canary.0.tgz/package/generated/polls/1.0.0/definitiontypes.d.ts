/** Generated from polls/1.0.0/definition.schema.json. Checksum: sha256:6aec3ae72255fe7a83405467a3fd69ebeb56651b8ca4d0a124db73bc7da670e5. Do not edit. */

export type Id = string;

export interface PollDefinitionV1 {
  schemaVersion: 'polls.definition@1.0.0';
  pollId: Id;
  revisionId: Id;
  question: string;
  selectionMode: 'single' | 'multiple';
  maxSelections?: number;
  /**
   * @minItems 2
   * @maxItems 6
   */
  options: [PollOption, PollOption, ...PollOption[]];
}
export interface PollOption {
  id: Id;
  label: string;
}
