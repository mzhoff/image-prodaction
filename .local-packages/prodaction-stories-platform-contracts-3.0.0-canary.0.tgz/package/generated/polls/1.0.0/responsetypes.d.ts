/** Generated from polls/1.0.0/response.schema.json. Checksum: sha256:55a91f8da3f812ff0d2cacac06ecc056dbac12c6be4e84812520c55142b86f57. Do not edit. */

export type Id = string;
export type PollResponseSource =
  | {
      kind: 'stories';
      snapshotId: Id;
      storyId: Id;
      storyRevisionId: Id;
      slideId: Id;
    }
  | {
      kind: 'embedded';
      surfaceKey: Key;
      contentId: Id;
      revisionId: Id;
    };
export type Key = string;

export interface PollResponseCommandV1 {
  schemaVersion: 'polls.response@1.0.0';
  submissionId: Id;
  pollId: Id;
  pollRevisionId: Id;
  occurrenceId: Id;
  /**
   * @minItems 1
   * @maxItems 6
   */
  selectedOptionIds: [Id, ...Id[]];
  source: PollResponseSource;
}
