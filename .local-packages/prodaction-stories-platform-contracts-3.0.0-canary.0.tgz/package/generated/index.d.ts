/** Generated package declarations. Do not edit by hand. */
export * from './story-feed/2.1.0/index.js';
