# REVERIE Identity client

Exact version 0.1.0-canary.9. Shared OIDC/PKCE consumer; products keep their own sessions and databases.

Canary.7 adds opt-in `telegramMode="embedded"` to `IdentityActions`, optional
`renderTerms` / `onEmbeddedStateChange(stage, busy)`, and `restartIdentityLogin(authPath)`.
Hosts placing restart in their own header can set `showRestartAction={false}`
and disable their button while the embedded callback reports busy/loading.
It requires Identity's `/v1/identity/telegram/authorize`, `/v1/identity/restart`
and `/api/auth/telegram/cancel` endpoints. Upgrade Identity before enabling it.
Redirect login remains the default for other consumers and for account linking.
The browser waits in the product card; only server-side code holds challenge,
PKCE and temporary session credentials. Explicit terms acceptance is required
for new accounts. Restart revokes the current product and SSO sessions and pending
attempt, then returns to the exact registered product origin. See the central
ADR `docs/adr/2026-09-21-embedded-telegram-login.md` for the contract and tests.

For reverse-proxied deployments, configure the consumer's trusted client-IP
resolution and list only the actual product/proxy peer IPs in Identity's
`IDENTITY_TRUSTED_PROXY_IPS`. The SDK forwards the resolved visitor IP; Identity
ignores forwarded headers from untrusted peers. Without this explicit configuration,
visitors share the existing product-server IP rate-limit bucket. No limits are disabled.

`createIdentityClient` verifies state, nonce, PKCE, issuer, audience, ID token and UserInfo subject using openid-client. `identityPlugin` adapts it to Better Auth 1.6.25. Only configured HTTPS origins are used; HTTP is allowed explicitly for loopback development. Identity clients use authorization code + S256 PKCE without a distributed client secret.

Migration required before enabling: make `user.email` nullable and add nullable UNIQUE `identitySubject`. Preserve all IDs. Existing accounts are linked through a recent product session; never link by email. Do not enable cookie session caches with stale account fields. No product roles or workspace membership are imported from Identity.

POST `/identity/start`: intent login/link, method email/telegram, termsAccepted, and local returnTo (document path + query/hash). The destination is persisted with the browser-bound attempt and validated against encoded/open redirects. enabledMethods limits the public login methods for Telegram-only deployments. GET `/identity/callback`: allowlisted deployment callback. Login attempts are single-use, browser-bound and expire in 5 minutes. New product users require explicit terms acceptance; existing email collision asks the user to sign into the old product account and link it.

Canary distribution: build and pack this directory once; ship the identical tarball to every consumer. It includes only the generic client and UI, never Identity server code, configuration or credentials. Registry publication is a separate release step.

## Canary.5: explicit proxy callback aliases

The canonical `redirectURI` / `REVERIE_IDENTITY_CALLBACK_URL` remains required.
Optional `additionalRedirectURIs` / `REVERIE_IDENTITY_CALLBACK_URLS` (a JSON array)
adds exact deployment callbacks. Example for a local Visual Intent proxy:

```dotenv
REVERIE_IDENTITY_CALLBACK_URL=http://localhost:3004/api/auth/identity/callback
REVERIE_IDENTITY_CALLBACK_URLS=["http://localhost:7310/api/auth/identity/callback","http://127.0.0.1:7310/api/auth/identity/callback"]
```

Register the same aliases as `additionalRedirectURIs` on the matching product in
Identity's `IDENTITY_PRODUCTS_JSON`, run its explicit migration command, and restart
the service. Product Better Auth `trustedOrigins` must also include those exact
origins. This does not turn arbitrary trusted CORS origins into OIDC callbacks.
Local HTTP still requires loopback development configuration; production remains
HTTPS-only unless the pre-existing explicit local development option is used.

The start request's exact `Origin` selects an already configured callback. The
server stores that selection beside state/nonce/PKCE and the browser-bound proof;
token exchange and final redirects use that stored callback, never request Host,
forwarded headers, or query parameters. All aliases must have the same callback
path, with no query/fragment and one callback per origin. Existing deployments
with one callback retain their behavior. No database migration is needed on the
consumer; in-flight canonical attempts remain valid during the upgrade.

Callback errors include `identity_method=email|telegram` from the stored attempt.
A `terms_required` response can resume the chosen method after explicit consent;
the client must not silently set `termsAccepted` on the initial login attempt.

## UI localization (canary.6)

`IdentityActions` accepts an optional `translate(message)` callback for its labels and error presentation. The default preserves Russian copy for existing consumers. Authentication requests, return URL validation, and consent state are unchanged. Hosts should use their shared UI catalog; no credential or profile data is passed to the callback.

Canary.9 adds optional host login telemetry and bounded ClientID attribution. Exceptions, blocked counters, invalid IDs and timeout never block sign-in. Only the embedded Telegram path transports attribution; email telemetry remains host-side.
